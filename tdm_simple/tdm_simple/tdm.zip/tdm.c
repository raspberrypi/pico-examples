/**
 * Copyright (c) 2020 Raspberry Pi (Trading) Ltd.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */


#include <stdio.h>
#include <stdlib.h>
#include "pico/stdlib.h"
#include "pico/stdio.h"
#include "pico/stdio/driver.h"
//#include "tusb.h"
#include "pico/binary_info.h"
#include "hardware/i2c.h"
#include "hardware/dma.h"
#include "hardware/irq.h"
//#include <hardware/flash.h>
#include "pio_tdm.h"
#include "ssd1306.h"
#include "Sydefs.h"
#include "smp_gse.h"
#include "ff.h"
#include "zmodem.h"
#include "diskio.h"


#define pin_txEN  6
#define pin_txADR 7
#define pin_txDAT 8

#define pin_rxCLK 16
#define pin_rxFRM 17
#define pin_rxADR 18
#define pin_rxDAT 19

#define pin_hssCLK 20
#define pin_hssFRM 21
#define pin_hssDAT 22

/*
#define BUF_SIZE 20
static uint16_t txbuf[BUF_SIZE];
static uint16_t rxbuf[BUF_SIZE];
*/

#define HssRxBufLen 256
uint16_t HssRxBufPtr= 0;
uint16_t HssRxBuf[HssRxBufLen];

uint16_t returned_sample;

// I2C
const uint I2C_DAT_PIN = 24;
const uint I2C_CLK_PIN = 25;
#define DISPLAY_ADDRESS 0x3c // 011110+SA0+RW - 0x3C or 0x3D
ssd1306_t disp;

/********************************************/
// Variables
/********************************************/
boolt execute_dump(void);
bool isOnHomepage = true;
bool isOnTailPage = false;
char globalFilename[256];
int currentIndex = 0;
int currentIndexClassic = 0;
int currentIndexNG = 0;
bool isOnAtmoPage = false;
bool isOnClassPage = false;
bool isOnNextGenPage = false;
bool isOnSerial = false;
bool serialClicked = false;
bool isOnNewAtmosphere = false;
bool isNewClassic = false;
bool isNewNextGen = false;
char selectedTail[20] = {0}; // For storing the selected tail
char selectedSerial[20] = {0};
bool ConfirmPage = false;
bool isConfirmed = false;
bool skipNextLine = false; 
bool skipNextLineTwo = false; 
int selectedLetterIndex = 0; // Index of the currently selected character in the word


/********************************************/
// FATfs
/********************************************/
FATFS fatFs;
FIL fileO;
DIR directoryO;
FILINFO fileInfo;
FRESULT resultF;
FATFS *fatFsPtr;
FIL *fp_dump;
char filename[20];

/********************************************/
// PIO
/********************************************/
pio_tdm_inst_t tdm = {
        .pio = pio0,
        .sm = 0
};

/********************************************/
// Queue Typedef & Declaration
/********************************************/
#define BufLen 2048
typedef struct {
    uint16_t InPtr;
    uint16_t OutPtr;
    uint16_t Buffer[BufLen];
} q;

q RxTDMQ;
q RxHSSQ;

/********************************************/
// PushQ :
/********************************************/
char PushQ (q* QPtr, unsigned Value) {
    uint32_t IntrptStatus;

    QPtr->Buffer[QPtr->InPtr] = Value;
//    IntrptStatus = save_and_disable_interrupts();
    if (((QPtr->InPtr + 1) % BufLen) != QPtr->OutPtr) {
        QPtr->InPtr = ((QPtr->InPtr + 1) % BufLen);
//        restore_interrupts (IntrptStatus);
        return (1);
    } else {
//        restore_interrupts (IntrptStatus);
        return (0);
    }
}

/********************************************/
// EmptyQ :
/********************************************/
char EmptyQ (q* QPtr) {
    return (QPtr->InPtr == QPtr->OutPtr);
}

/********************************************/
// PopQ :
/********************************************/
unsigned PopQ (q* QPtr) {
    unsigned ReturnVal;
    uint32_t IntrptStatus;

    if (EmptyQ (QPtr)) {
        ReturnVal = 0xffffffff;
    } else {
//        IntrptStatus = save_and_disable_interrupts();
        ReturnVal = QPtr->Buffer[QPtr->OutPtr];
        QPtr->OutPtr = ((QPtr->OutPtr + 1) % BufLen);
//        restore_interrupts (IntrptStatus);
    }
    return (ReturnVal);
}

/********************************************/
// RxTDM ISR
/********************************************/
static void __not_in_flash_func(pio_irq0_handler)(void) {
    while (!pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm))) {
            PushQ (&RxTDMQ, *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm)]));
    }
}

/********************************************/
// RxHSS ISR
/********************************************/
static void __not_in_flash_func(pio_irq1_handler)(void) {
    while (!pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm+3))) {
            PushQ (&RxHSSQ, *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm+3)]));
    }
}

/********************************************/
// TxMux - Multiplexed, byte stuffed tx
/********************************************/
/*
#define TxMuxBufLen 64 
char TxMuxBuf[TxMuxBufLen];
uint16_t TxMuxPtr = 0;
char TxMuxChan=0;
void TxMux (char chan, uint16_t len, char *message) {
    tud_cdc_n_write (0,"\x7e",1);
    tud_cdc_n_write (0,&chan,1);
    
    while (len) {
        if ((*(char *)message == 0x7d)  || (*(char *)message == 0x7e)) {
            tud_cdc_n_write (0,"\x7d",1);
            *(char *)message ^= 0x40;
        }
        tud_cdc_n_write (0,message,1);
        message++;
        len--;
    }

//    tud_cdc_n_write (0,message,len);
    tud_cdc_n_write_flush (0);
}
*/

/*
    TxMuxPtr = 0;
//    if (chan != TxMuxChan) {
        TxMuxBuf[TxMuxPtr++] = 0x7e;
        TxMuxBuf[TxMuxPtr++] = chan;
//    }

    for (int i=0; i<len; i++) {
        if ((message[i] == 0x7d)  || (message[i] == 0x7e)) {
            TxMuxBuf[TxMuxPtr++] = 0x7d;
            TxMuxBuf[TxMuxPtr++] = message[i] ^ 0x40;
        } else
            TxMuxBuf[TxMuxPtr++] = message[i];

        if (TxMuxPtr >= (TxMuxBufLen-2)) {
            tud_cdc_n_write (0,TxMuxBuf,TxMuxPtr);
            tud_cdc_n_write_flush (0);
            TxMuxPtr = 0;
        }
    }

    if (TxMuxPtr) {
        tud_cdc_n_write (0,TxMuxBuf,TxMuxPtr);
        tud_cdc_n_write_flush (0);
    }
*/

/********************************************/
// RxMux - Multiplexed, byte stuffed rx
/********************************************/
/*
#define RxMuxBufLen 64
char RxMuxBuf[RxMuxBufLen];
uint16_t RxMuxPtr = 0;
char RxMuxChan = 0;
typedef enum {
  SCAN,
  SOF,
  ESC,
  NORM
} RxMuxStateType;
RxMuxStateType RxMuxState = NORM;

uint16_t RxMux (char *chan, char *message) {
    char inchar;

    while (tud_cdc_n_available(0)) {
        tud_cdc_n_read (0, &inchar, 1);
        switch (RxMuxState) {
            case SCAN:
                if (inchar == 0x7e) 
                    RxMuxState = SOF;
            case SOF:
                RxMuxPtr = 0;
                RxMuxChan = inchar;
                RxMuxState = NORM;
                break;

            case ESC:
                RxMuxBuf[RxMuxPtr++] = inchar ^ 0x40;
                RxMuxState = NORM;
                break;

            case NORM:
                if (inchar == 0x7e) {
                    RxMuxState = SOF;
                } else if (inchar == 0x7d) {
                    RxMuxState = ESC;
                } else {
                    message[RxMuxPtr++] = inchar;
                }
                break;
        }

        if (RxMuxPtr >= 2) {
            *chan = RxMuxChan;
//            message = RxMuxBuf;
            RxMuxPtr = 0;
            return (1);
        } 
    }

    return (0);
}
*/

/********************************************/
// main
/********************************************/
char temps[100];
int main() {
    // Enable UART so we can print status output
    stdio_init_all();
    getchar_timeout_us(0);
    //----------------------------
    // Enable FA2100 GSE discrete
    //----------------------------
    gpio_init(2);
    gpio_set_dir(2, GPIO_OUT);
    gpio_put(2,1);

    //----------------------------
    // Enable FA2100 SMP/FDP discrete
    //----------------------------
    gpio_init(0);
    gpio_set_dir(0, GPIO_OUT);
    gpio_put(0,1);

    //----------------------------
    // Temporary Display Reset
    //----------------------------
    gpio_init(9);
    gpio_set_dir(9, GPIO_OUT);
    gpio_put(9,0);
    sleep_ms(10);
    gpio_put(9,1);

    //-------------------------------
    // Initialize Scroll Switch Input
    //-------------------------------
    int i;
    for (i=3; i<=5; i++) {
      gpio_init (i);
      gpio_set_dir(i, GPIO_IN);
      gpio_pull_up(i);
    }

    printf("Initializing I2C... ");
    //----------------------------
    // Initialize I2C 
    //----------------------------
    i2c_init(i2c0, 400 * 1000);
    gpio_set_function(I2C_DAT_PIN, GPIO_FUNC_I2C);
    gpio_set_function(I2C_CLK_PIN, GPIO_FUNC_I2C);
    gpio_pull_up(I2C_DAT_PIN);
    gpio_pull_up(I2C_CLK_PIN);
    bi_decl(bi_2pins_with_func(I2C_DAT_PIN, I2C_CLK_PIN, GPIO_FUNC_I2C));

    printf("Success.\n");
    //----------------------------
    // Initialize Display
    //----------------------------
 disp.external_vcc=false;
    sleep_ms(100);
    ssd1306_init(&disp, 128, 64, 0x3c, i2c0);

    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp,0,0, 2,"Send (U)");
    ssd1306_draw_string(&disp,0,20, 2,"Recieve (P)");
    ssd1306_draw_string(&disp,0,40, 2,"List (D)");
    ssd1306_show(&disp);
/*
    int rs=0;
    char display_string[20];
    while (1==1) {
        ssd1306_clear(&disp);
        for (i=3; i<=5; i++) 
            if (!gpio_get(i))
                ssd1306_draw_square(&disp,(i-3)*30,30,20,20);
        sprintf (display_string,"%i",rs++);
        ssd1306_draw_string(&disp,0,0,2,display_string);
        ssd1306_show(&disp); 
        sleep_ms(100);
        }
*/
    // 
    // Initialize Flash Memory
    //
/*    
    unsigned char *p = (unsigned char *)XIP_BASE;
    int ptr;
    
//    while (!tud_cdc_n_available(0));
    while (getchar_timeout_us(0) ==  PICO_ERROR_TIMEOUT);


    uint32_t IntSave = save_and_disable_interrupts();

    flash_range_erase (0x100000, FLASH_SECTOR_SIZE);

    unsigned char WriteBuffer[FLASH_PAGE_SIZE] = "1234567890.";
    flash_range_program (0x100000, WriteBuffer, FLASH_PAGE_SIZE);

    restore_interrupts (IntSave);

    p += 0x100000;
    for (ptr=0; ptr<512; ptr++) {  
        if ((ptr % 16) == 0) {
            printf ("\r\n%08x-",p+ptr);
        }
        printf ("%02x ", p[ptr]);
    }

    while (1==1) {}
*/

    // 
    // Initialize TDM receivers and transmitters
    //
    gpio_init(pin_txEN);
    gpio_set_dir(pin_txEN, GPIO_OUT);
    gpio_put(pin_txEN, 0);
    gpio_init(pin_txADR);
    gpio_set_dir(pin_txADR, GPIO_OUT);
    gpio_put(pin_txADR, 0);
    gpio_init(pin_txDAT);
    gpio_set_dir(pin_txDAT, GPIO_OUT);
    gpio_put(pin_txDAT, 0);

    float clkdiv = 31.25f;  // 2 MHz @ 125 clk_sys
    uint TDMtx_prog_offs = pio_add_program(tdm.pio, &TDMtx_program);
    uint TDMrx_prog_offs = pio_add_program(tdm.pio, &TDMrx_program);
    uint HSSrx_prog_offs = pio_add_program(tdm.pio, &HSSrx_program);
    pio_TDMrx_init(tdm.pio, tdm.sm,
                    TDMrx_prog_offs,
                    16,       // 16 bits per TDM ADR/DAT frame
                    clkdiv/8,
                    pin_rxDAT
    );
    // Enable FIFO interrupt in the PIO itself
    irq_set_exclusive_handler(PIO0_IRQ_0, pio_irq0_handler);
    pio_set_irq0_source_enabled(pio0,  pis_sm0_rx_fifo_not_empty, true);
    // Enable IRQ in the NVIC
    irq_set_enabled(PIO0_IRQ_0, true);

    pio_TDMtx_init(tdm.pio, tdm.sm + 1,
                    TDMtx_prog_offs,
                    16,       // 16 bits per TDM ADR/DAT frame
                    clkdiv/8,
                    pin_txEN,
                    pin_txDAT
    );

    pio_TDMtx_init(tdm.pio, tdm.sm + 2,
                    TDMtx_prog_offs,
                    16,       // 16 bits per TDM ADR/DAT frame
                    clkdiv/8,
                    pin_txEN,
                    pin_txADR
    );

    pio_HSSrx_init(tdm.pio, tdm.sm+3,
                    HSSrx_prog_offs,
                    16,       // 16 bits per TDM ADR/DAT frame
                    clkdiv/8,
                    pin_hssDAT
    );
     // Enable FIFO interrupt in the PIO itself
    irq_set_exclusive_handler(PIO0_IRQ_1, pio_irq1_handler);
    pio_set_irq1_source_enabled(pio0,  pis_sm3_rx_fifo_not_empty, true);
    // Enable IRQ in the NVIC
    irq_set_enabled(PIO0_IRQ_1, true);
   


    //
    // Initialize temporary CLK/FRM source
    //
/*
    uint TDMclk_prog_offs = pio_add_program(tdm.pio, &TDMclk_program);
    pio_TDMclk_init(tdm.pio, tdm.sm + 2,
                    TDMclk_prog_offs,
                    16,       // 16 bits per TDM ADR/DAT frame
                    clkdiv,
                    pin_txCLK
    );
*/
    //---------------------------------------------------
    //
    //  DMA transfer
    //
    //---------------------------------------------------
    // Get a free channel, panic() if there are none
/*    
    int chan = dma_claim_unused_channel(true);
    dma_channel_config c = dma_channel_get_default_config(chan);
    channel_config_set_transfer_data_size(&c, DMA_SIZE_16);
    channel_config_set_read_increment(&c, true);
    channel_config_set_write_increment(&c, false);
    channel_config_set_dreq(&c, DREQ_PIO0_TX1);
*/

    // initialize random transmit buffer
/*    uint16_t *dst,*src;
    size_t tx_remain, rx_remain;
    for (int i = 0; i < BUF_SIZE; ++i) 
        txbuf[i] = rand() >> 16;
*/    //
    // Big forever TEST loop
    //

//    while (tud_cdc_n_available(0)) 
//        tud_cdc_n_read (0, &c, 1);

    uint32_t NextTimeUpdate=0;

    while (1==1) {
/*        
        if (!pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm))) {
            returned_sample = *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm)]);
            if (((returned_sample & 0xff00) == 0x1000) || ((returned_sample & 0xff00) == 0x6c00))
                printf ("%c",returned_sample & 0x7f);
            else    
                printf ("[%04x]", returned_sample);
        }
*/
        while (!EmptyQ (&RxTDMQ)) {
            returned_sample = PopQ (&RxTDMQ);
//            TxMux (0,2,(char *) &returned_sample);

            if (((returned_sample & 0xff00) == 0x1000) || ((returned_sample & 0xff00) == 0x6c00)) {
                putchar_raw ((char) (returned_sample & 0x7f));
                stdio_flush();
//                tud_cdc_n_write_char (0,(char) (returned_sample & 0x7f));
//                tud_cdc_write_flush();
            }
            else {   
                sprintf (temps,"[%04x]", returned_sample);
                PutString_Block (temps);
//                stdio_usb.out_chars(temps,strlen(temps));
                stdio_flush();
//                tud_cdc_n_write (0,temps,strlen(temps));
//                tud_cdc_n_write_flush (0);
            }

        }

        // Buffer HSS receptions
//        if (!pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm+3))) 
//            HssRxBuf[HssRxBufPtr++] = *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm+3)]);


        while  (!EmptyQ (&RxHSSQ)) {
//            returned_sample = PopQ (&RxHSSQ);
//            TxMux (1,2,(char *) &returned_sample);
             HssRxBuf[HssRxBufPtr++] = PopQ (&RxHSSQ);
        }


/*
        char PacifierString[20];
        if (to_ms_since_boot(get_absolute_time()) > NextTimeUpdate) {
            NextTimeUpdate = to_ms_since_boot(get_absolute_time()) + 500;
            sprintf (PacifierString,"%i\n",NextTimeUpdate);
            for (int i=0; i<strlen(PacifierString); i++) 
                TxMux (0,2,PacifierString+i);
        }
*/

        if (HssRxBufPtr == HssRxBufLen) {
//            TxMux (1,HssRxBufPtr*2,(char *)HssRxBuf);
            
            for (HssRxBufPtr=0; HssRxBufPtr<HssRxBufLen; HssRxBufPtr++) {  
                if ((HssRxBufPtr % 8) == 0) {
                    sprintf (temps,"\r\n%04x-",HssRxBufPtr);
                    PutString_Block (temps);
//                    stdio_usb.out_chars(temps,strlen(temps));
//                    tud_cdc_n_write (0,temps,strlen(temps));
                }
                sprintf (temps,"%04x ", HssRxBuf[HssRxBufPtr]);
                PutString_Block (temps);
//                stdio_usb.out_chars(temps,strlen(temps));
//                tud_cdc_n_write (0,temps,strlen(temps));
            }
 
        stdio_flush();
//            tud_cdc_write_flush();
            HssRxBufPtr = 0;                
        }


/*
        char RxMuxChan;
        uint16_t FAcommand;
        if (RxMux(&RxMuxChan, &FAcommand)) {
            *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+1)]) = FAcommand;
            *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+2)]) = 0x4000;
        }
*/
        uint32_t ReadLen;
        char inchar;
        if ((inchar = getchar_timeout_us(0)) !=  PICO_ERROR_TIMEOUT) {
//          if (tud_cdc_n_available(0)) {
//            if (ReadLen = tud_cdc_n_read (0, &inchar, 1)) {
                if ((inchar & 0xff) == 'X') {
                    *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+1)]) = 0x0000;
                    *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+2)]) = 0x4000;
                } else if ((inchar & 0xff) == 'Y') {
                    HssRxBufPtr = 0;
                    *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+1)]) = 0x1301;
                    *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+2)]) = 0x4000;
                } else if ((inchar & 0xff) == 'Z') {
                    ReadDFDR();
                } else if ((inchar & 0xff) == 'S') {

/*
                    sd_card_t *pSD = sd_get_by_num(0);
                    FRESULT fr = f_mount(&pSD->fatfs, pSD->pcName, 1);
                    if (FR_OK != fr) panic("f_mount error: %s (%d)\n", FRESULT_str(fr), fr);
*/
/*
                    if (!arg1) arg1 = sd_get_by_num(0)->pcName;
                    FATFS *p_fs = sd_get_fs_by_name(arg1);
                    if (!p_fs) {
                        printf("Unknown logical drive number: \"%s\"\n", arg1);
                        return;
                    }
                    FRESULT fr = f_mount(p_fs, arg1, 1);
                    if (FR_OK != fr) {
                        printf("f_mount error: %s (%d)\n", FRESULT_str(fr), fr);
                        return;
                    }
                    sd_card_t *pSD = sd_get_by_name(arg1);
                    myASSERT(pSD);
                    pSD->mounted = true;
*/
                    SendZmodem();
/*
                    resultF = f_mount(&fatFs, "0:", 1);
                    if (FR_OK != resultF) printf ("f_mount error\n");
                    zsend ("DUMP0001.FDR");
                    resultF = f_unmount("0:"); 
*/
                }


//            }
       }


        if (!gpio_get(4) && isOnHomepage) {
            // User wants to see options
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Classic (U)");
            ssd1306_draw_string(&disp, 0, 20, 2, "NewGen (P)");
            ssd1306_draw_string(&disp, 0, 40, 2, "Atmo (D)");
            ssd1306_show(&disp);
            isOnTailPage = true;
            isOnHomepage = false; // Now, we're not on the homepage anymore
            sleep_ms(500);
        }
        
        if (!gpio_get(3) && isOnTailPage) { // Assuming GPIO 3 is "scroll down"
            printf("Navigating to Atmosphere page...\n");
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Atmosphere");
            ssd1306_draw_string(&disp, 0, 20, 2, "Tails:");
            ssd1306_draw_string(&disp, 0, 40, 2, "Serial:");
            ssd1306_show(&disp);
                isOnAtmoPage = true;
                isOnClassPage = false; 
                isOnTailPage = false;
                isOnNextGenPage = false;
                sleep_ms(500);

        }

        if(isOnAtmoPage){
            if (!gpio_get(3)) { // Assuming GPIO 3 is "scroll down"   
                handleScrollDownAtmo();
            }
            if (!gpio_get(5)) { // Assuming GPIO 5 is "scroll up"
                handleScrollUpAtmo();
        }
        }

        if (!gpio_get(4) && isOnSerial) { 
            serialClicked = true;
            isOnNextGenPage = false;
            isOnClassPage = false;
            isOnAtmoPage = false;
            isOnTailPage = false;
            sleep_ms(500);
        }
        if(serialClicked){
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Tails:");
            ssd1306_draw_string(&disp, 0, 20, 2, "0000000");
            ssd1306_show(&disp);
            handleInputs();
            DisplayWordUpdate();
        }


        if (!gpio_get(5) && isOnTailPage) { // Assuming GPIO 5 is "scroll up"
            ssd1306_draw_string(&disp, 0, 0, 2, "Classic");
            printf("Navigating to Classic page...\n");
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Classic");
            ssd1306_draw_string(&disp, 0, 20, 2, "Tails:");
            ssd1306_draw_string(&disp, 0, 40, 2, "Serial:");
            ssd1306_show(&disp);
            isOnClassPage = true;
            isOnAtmoPage = false;
            isOnTailPage = false;
            isOnNextGenPage = false;
            sleep_ms(500);
        }



         if(isOnClassPage){
            if (!gpio_get(3)) { // Assuming GPIO 3 is "scroll down"   
                handleScrollDownClassic();
            }
            if (!gpio_get(5)) { // Assuming GPIO 5 is "scroll up"
                handleScrollUpClassic();
        }
        }       



        if (!gpio_get(4) && isOnTailPage) { // Assuming GPIO 4 is "push"
            ssd1306_draw_string(&disp, 0, 0, 2, "Next Gen");
            printf("Navigating to Next Gen page...\n");
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Next Gen");
            ssd1306_draw_string(&disp, 0, 20, 2, "Tails:");
            ssd1306_draw_string(&disp, 0, 40, 2, "Serial:");
            ssd1306_show(&disp);
            isOnNextGenPage = true;
            isOnClassPage = false;
            isOnAtmoPage = false;
            isOnTailPage = false;
            sleep_ms(500);
        }



         if(isOnNextGenPage){
            if (!gpio_get(3)) { // Assuming GPIO 3 is "scroll down"   
                handleScrollDownNG();
            }
            if (!gpio_get(5)) { // Assuming GPIO 5 is "scroll up"
                handleScrollUpNG();
        }
        }  

    if (!gpio_get(4) && isOnNewAtmosphere) {
        isOnAtmoPage = false;
        // User has chosen an option and now needs to confirm
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Confirm (U)");
        ssd1306_draw_string(&disp, 0, 20, 2, "Back (D)");
        ssd1306_show(&disp);
        isOnNewAtmosphere = false;
        ConfirmPage = true;
    }

    // Handle confirmation
    if (ConfirmPage) {
        if (!gpio_get(5)) { // Assuming GPIO 5 is "Confirm"
            // User confirmed
            ReadDFDR();
            ConfirmPage = false; // Reset confirmation page flag
            // Optionally, navigate user to another page or refresh current page
        }
        
        if (!gpio_get(3)) { // Assuming GPIO 3 is "Back"
            isOnNewAtmosphere = false;
            isNewClassic = false;
            isNewNextGen = false;
            ConfirmPage = false;
            isOnTailPage = true;

    // Display the Tail Page options
         ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Classic (U)");
            ssd1306_draw_string(&disp, 0, 20, 2, "NewGen (P)");
            ssd1306_draw_string(&disp, 0, 40, 2, "Atmo (D)");
            ssd1306_show(&disp);
           
        }
        sleep_ms(500);
    }

    if (!gpio_get(4) && isNewClassic) {
        isOnClassPage = false;
        // User has chosen an option and now needs to confirm
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Confirm (U)");
        ssd1306_draw_string(&disp, 0, 20, 2, "Back (D)");
        ssd1306_show(&disp);
        isNewClassic = false;
        ConfirmPage = true;
    }

        if (ConfirmPage) { // Assuming GPIO 4 is "push"
            if (!gpio_get(5)) { // Assuming GPIO 5 is "Confirm"
            // User confirmed
            ReadDFDR();
            ConfirmPage = false; // Reset confirmation page flag
            // Optionally, navigate user to another page or refresh current page
        }
        
        if (!gpio_get(3)) { // Assuming GPIO 3 is "Back"
            
            isOnNewAtmosphere = false;
            isNewClassic = false;
            isNewNextGen = false;
            ConfirmPage = false;
            isOnTailPage = true;

            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Classic (U)");
            ssd1306_draw_string(&disp, 0, 20, 2, "NewGen (P)");
            ssd1306_draw_string(&disp, 0, 40, 2, "Atmo (D)");
            ssd1306_show(&disp);
            ConfirmPage = false; // Reset confirmation page flag
            // Set appropriate flag to indicate where to go back
        }
            sleep_ms(500);
        }

        if (!gpio_get(4) && isNewNextGen) {
        isOnNextGenPage = false;
        // User has chosen an option and now needs to confirm
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Confirm (U)");
        ssd1306_draw_string(&disp, 0, 20, 2, "Back (D)");
        ssd1306_show(&disp);
        isNewNextGen = false;
        ConfirmPage = true;
    }

        if (ConfirmPage) { // Assuming GPIO 4 is "push"
            if (!gpio_get(5)) { // Assuming GPIO 5 is "Confirm"
            // User confirmed
            ReadDFDR();
            ConfirmPage = false; // Reset confirmation page flag
            // Optionally, navigate user to another page or refresh current page
        }
        
        if (!gpio_get(3)) { // Assuming GPIO 3 is "Back"
            
            isOnNewAtmosphere = false;
            isNewClassic = false;
            isNewNextGen = false;
            ConfirmPage = false;
            isOnTailPage = true;
            
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Classic (U)");
            ssd1306_draw_string(&disp, 0, 20, 2, "NewGen (P)");
            ssd1306_draw_string(&disp, 0, 40, 2, "Atmo (D)");
            ssd1306_show(&disp);
            ConfirmPage = false; // Reset confirmation page flag
            // Set appropriate flag to indicate where to go back
        }
        sleep_ms(500);
        }





        // If GPIO 3 (ReadDFDR) is pressed and we are on the homepage
        if (!gpio_get(3) && isOnHomepage) {
            list_files();
            // ReadDFDR();
           
        }
        // If GPIO 5 (SendZmodem) is pressed and we are on the homepage
        if (!gpio_get(5) && isOnHomepage) {
            SendZmodem(); // Call function to handle SendZmodem action
        }


}


//            printf ("{");
//            for (int i=0; i<8; i++) {
//                while (pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm+3)));
//                returned_sample = *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm+3)]);
//                printf ("%04x", returned_sample);
//            }
//            printf ("}");

        

 
/*
        uint16_t returned_sample=0;
        // transmit a randow word 
        while (pio_sm_is_tx_fifo_full(tdm.pio, tdm.sm + 1));
        uint16_t random_sample = rand() >> 16;
        *((io_rw_16 *) &tdm.pio->txf[tdm.sm + 1]) = random_sample;
        // .... and await a response
        uint32_t timeout =  time_us_32();
        timeout += 10000;
        while (timeout > time_us_32()) {
            if (!pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm))) {
                if ((returned_sample = *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm)])) == random_sample)
                    break;
            }
        }
        if (returned_sample == random_sample)
            printf ("%04x ", returned_sample);
        else
            printf ("[%04x %04x]",random_sample,returned_sample);;
*/

/*
        // new random TX data
        for (int i = 0; i < BUF_SIZE; ++i) 
            txbuf[i] = rand() >> 16;

        // Test transmitter/receiver
        printf("TX:");
        for (int i = 0; i < BUF_SIZE; ++i) {
            rxbuf[i] = 0;
            printf(" %04x", (int) txbuf[i]);
        }
        printf("\n");

        tx_remain = BUF_SIZE;
        rx_remain = BUF_SIZE;
        dst = rxbuf;
        src = txbuf;
        while (tx_remain || rx_remain) {
            if (tx_remain && !pio_sm_is_tx_fifo_full(tdm.pio, tdm.sm + 1)) {
                *((io_rw_16 *) &tdm.pio->txf[tdm.sm + 1]) = *src++;
                --tx_remain;
            }
            if (rx_remain && !pio_sm_is_rx_fifo_empty(tdm.pio, (tdm.sm))) {
                *dst = *((io_rw_16 *) &tdm.pio->rxf[(tdm.sm)]);
                if (*dst != 0xffff)
                    {
                    dst++;
                    --rx_remain;
                }
            }
        }

        
        printf("RX:");
        bool mismatch = false;
        for (int i = 0; i < BUF_SIZE; ++i) {
            printf(" %04x", (int) rxbuf[i]);
            mismatch = mismatch || rxbuf[i] != txbuf[i];
        }
        if (mismatch)
            printf("\nNope-------------------------------------------------------------------------------------------------\n");
        else
            printf("\nOK\n");

*/

/*
        // We could choose to go and do something else whilst the DMA is doing its
        // thing. In this case the processor has nothing else to do, so we just
        // wait for the DMA to finish.
       dma_channel_configure(
            chan,                       // Channel to be configured
            &c,                         // The configuration we just created
            &tdm.pio->txf[tdm.sm + 1],  // The initial write address
            txbuf,                      // The initial read address
            20,                         // Number of transfers
            true                        // Start immediately.
        );
       dma_channel_wait_for_finish_blocking(chan);
*/

/*        
        printf("\nI2C Bus Scan\n");
        printf("   0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\n");

        for (int addr = 0; addr < (1 << 7); ++addr) {
            if (addr % 16 == 0) {
                printf("%02x ", addr);
            }

            // Perform a 1-byte dummy read from the probe address. If a slave
            // acknowledges this address, the function returns the number of bytes
            // transferred. If the address byte is ignored, the function returns
            // -1.

            // Skip over any reserved addresses.
            int ret;
            uint8_t rxdata;
            if (reserved_addr(addr))
                ret = PICO_ERROR_GENERIC;
            else
                ret = i2c_read_blocking(i2c_default, addr, &rxdata, 1, false);

            printf(ret < 0 ? "." : "@");
            printf(addr % 16 == 15 ? "\n" : "  ");
        }
        printf("Done.\n\n");
*/

//        sleep_ms (100);
}

/********************************************/
// Send file via Zmodem 
/********************************************/
// void SendZmodem () {
//     resultF = f_mount(&fatFs, "0:", 1);
//     if (FR_OK != resultF) printf ("f_mount error\n");
//     zsend ("DUMP0001.FDR");
//     resultF = f_unmount("0:"); 
// }





// void SendZmodem() {
//     DIR dir;
//     FILINFO fno;
//     FRESULT fr;
//     char newestFileName[256] = {0}; // Assuming a max filename length of 255
//     DWORD newestFileDate = 0; // To track the date of the newest file

//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Uploading");
//     ssd1306_draw_string(&disp, 0, 20, 2, "Data Files");
//     ssd1306_show(&disp);

//     // Mount the filesystem
//     resultF = f_mount(&fatFs, "0:", 1);
//     if (resultF != FR_OK) {
//         printf("f_mount error\n");
//         return;
//     }

//     // Open the root directory
//     fr = f_opendir(&dir, "/");
//     if (fr == FR_OK) {
//         while (1) {
//             fr = f_readdir(&dir, &fno); // Read a directory item
//             if (fr != FR_OK || fno.fname[0] == 0) break; // Break on error or end of dir
//             // Skip directories and files starting with ._
//             if (!(fno.fattrib & AM_DIR) && strncmp(fno.fname, "._", 2) != 0) {
//                 // Compare the last modified date to find the newest file
//                 if ((fno.fdate << 16 | fno.ftime) > newestFileDate) {
//                     newestFileDate = fno.fdate << 16 | fno.ftime; // Update the newest file date
//                     strcpy(newestFileName, fno.fname); // Update the newest file name found
//                 }
//             }
//         }
//         f_closedir(&dir);
//     } else {
//         printf("Failed to open directory\n");
//     }

//     // Proceed only if a newest file has been identified
//     if (newestFileName[0] != 0) {
//         zsend(newestFileName);
//     } else {
//         printf("No suitable files found to send\n");
//     }

//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Upload");
//     ssd1306_draw_string(&disp, 0, 20, 2, "Complete");
//     ssd1306_show(&disp);

//     // Unmount SD card
//     resultF = f_unmount("0:");

//     sleep_ms(5000);

//     // Clear the display and show the original "Send" and "Receive" page
//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Send (U)");
//     ssd1306_draw_string(&disp, 0, 20, 2, "Receive (P)");
//     ssd1306_draw_string(&disp, 0, 40, 2, "List (D)");
//     ssd1306_show(&disp);
// }


void SendZmodem() {
    DIR dir;
    FILINFO fno;
    FRESULT fr;
    char newestFileName[256] = {0}; // Buffer for the file name with the highest sequence number
    unsigned int highestSequenceNumber = 0; // To track the highest sequence number found

    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Uploading");
    ssd1306_draw_string(&disp, 0, 20, 2, "Data Files");
    ssd1306_show(&disp);

    // Mount the filesystem
    resultF = f_mount(&fatFs, "0:", 1);
    if (resultF != FR_OK) {
        printf("f_mount error\n");
        return;
    }

    // Open the root directory
    fr = f_opendir(&dir, "/");
    if (fr == FR_OK) {
        while (1) {
            fr = f_readdir(&dir, &fno);
            if (fr != FR_OK || fno.fname[0] == 0) break; // End of directory

            if (!(fno.fattrib & AM_DIR)) { // Skip directories
                unsigned int currentSequenceNumber = 0;
                if (sscanf(fno.fname, "%*[^_]_%u.FDR", &currentSequenceNumber) == 1) {
                    if (currentSequenceNumber > highestSequenceNumber) {
                        highestSequenceNumber = currentSequenceNumber;
                        strcpy(newestFileName, fno.fname); // Update the file name with the highest sequence number
                    }
                }
            }
        }
        f_closedir(&dir);
    } else {
        printf("Failed to open directory\n");
    }

    // Unmount SD card not needed before sending
    // resultF = f_unmount("0:");

    if (newestFileName[0] != '\0') {
        printf("Attempting to send file: %s\n", newestFileName);
        zsend(newestFileName); // Call zsend directly without pre-opening the file
    } else {
        printf("No suitable files found to send.\n");
    }

    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Upload");
    ssd1306_draw_string(&disp, 0, 20, 2, "Complete");
    ssd1306_show(&disp);

    sleep_ms(5000);

    // Clear the display for user navigation
    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Send (U)");
    ssd1306_draw_string(&disp, 0, 20, 2, "Receive (P)");
    ssd1306_draw_string(&disp, 0, 40, 2, "List (D)");
    ssd1306_show(&disp);
}




/********************************************/
// ReadDFDR
/********************************************/


// void ReadDFDR () {
//     int i;
//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Downloading");
//     ssd1306_draw_string(&disp, 0, 20, 2, "FDR Data..");
//     ssd1306_show(&disp);
//     boolt execute_dump (void);

//     // clear any incoming STDIO
//     while (getchar_timeout_us(0) != PICO_ERROR_TIMEOUT);

//      // Execute DFDR Download
//     resultF = f_mount(&fatFs, "0:", 1);
//     fp_dump = &fileO;
//     i=0;
//     do {
//         sprintf (filename,"DUMP%4.4i.FDR",i++);
//     } while (f_open(fp_dump, filename, FA_WRITE | FA_CREATE_NEW) != FR_OK);
//     // f_open(fp_dump, "DUMP0001.FDR", FA_WRITE);
//     execute_dump();
//     f_close (fp_dump);
//     resultF = f_unmount("0:"); 
//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "FDR");
//     ssd1306_draw_string(&disp, 0, 20, 2, "Download");
//     ssd1306_draw_string(&disp, 0, 40, 2, "Complete");
//     ssd1306_show(&disp);

//     sleep_ms(5000);

//     // Clear the display and show the original "Send" and "Receive" page
//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Send (U)");
//     ssd1306_draw_string(&disp, 0, 20, 2, "Receive (D)");
//     ssd1306_draw_string(&disp,0,40, 2,"List (P)");
//     ssd1306_show(&disp);
// }
                   

char selectedWord[8] = "A000000";


// void ReadDFDR() {
//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Downloading");
//     ssd1306_draw_string(&disp, 0, 20, 2, "FDR Data..");
//     ssd1306_show(&disp);

//     // Clear any incoming STDIO
//     while (getchar_timeout_us(0) != PICO_ERROR_TIMEOUT);

//     // Execute DFDR Download
//     resultF = f_mount(&fatFs, "0:", 1);
//     fp_dump = &fileO;

//     // Use selectedTail and selectedSerial to generate the filename
//     sprintf(filename, "T_%s_S_N_%s.FDR", selectedTail, selectedSerial);

//     // Try to open the file. If it exists or can be created, proceed with the dump.
//     if (f_open(fp_dump, filename, FA_WRITE | FA_CREATE_ALWAYS) == FR_OK) {
//         // If the file is successfully opened/created, execute the dump.
//         if (execute_dump()) {
//             // Dump was successful
//             ssd1306_clear(&disp);
//             ssd1306_draw_string(&disp, 0, 0, 2, "FDR");
//             ssd1306_draw_string(&disp, 0, 20, 2, "Download");
//             ssd1306_draw_string(&disp, 0, 40, 2, "Complete");
//             ssd1306_show(&disp);
//         } else {
//             // Handle dump failure
//             ssd1306_clear(&disp);
//             ssd1306_draw_string(&disp, 0, 0, 2, "Dump Error");
//             ssd1306_show(&disp);
//         }
//         f_close(fp_dump); // Always close the file after the operation
//     } else {
//         // If the file couldn't be opened/created, display an error message
//         ssd1306_clear(&disp);
//         ssd1306_draw_string(&disp, 0, 0, 2, "File Error");
//         ssd1306_show(&disp);
//     }

//     resultF = f_unmount("0:"); // Unmount the filesystem

//     sleep_ms(5000); // Wait a bit before clearing the display

//     // Clear the display and show the original "Send", "Receive", and "List" page
//     ssd1306_clear(&disp);
//     ssd1306_draw_string(&disp, 0, 0, 2, "Send (U)");
//     ssd1306_draw_string(&disp, 0, 20, 2, "Receive (D)");
//     ssd1306_draw_string(&disp, 0, 40, 2, "List (P)");
//     ssd1306_show(&disp);
// }

#include "stdio.h"
#include "stdlib.h"

// Reads the current sequence number from a file
#include "ff.h" // Make sure you include the FatFs library header

// Reads the current sequence number from a file using FatFs
unsigned int readSequenceNumber() {
    FIL fil; // File object
    unsigned int seqNum = 0;
    FRESULT fr = f_open(&fil, "sequence_number.txt", FA_READ);
    if (fr == FR_OK) {
        char buffer[10];
        UINT bytesRead;
        f_read(&fil, buffer, sizeof(buffer)-1, &bytesRead);
        buffer[bytesRead] = '\0'; // Null terminate the string
        seqNum = atoi(buffer); // Convert to integer
        f_close(&fil);
    } else {
        printf("Failed to open sequence_number.txt for reading.\n");
    }
    return seqNum;
}

// Writes the sequence number to a file using FatFs
void writeSequenceNumber(unsigned int seqNum) {
    FIL fil; // File object
    FRESULT fr = f_open(&fil, "sequence_number.txt", FA_WRITE | FA_CREATE_ALWAYS);
    if (fr == FR_OK) {
        char buffer[10];
        sprintf(buffer, "%u", seqNum); // Convert integer to string
        UINT bytesWritten;
        f_write(&fil, buffer, strlen(buffer), &bytesWritten);
        f_close(&fil);
    } else {
        printf("Failed to open sequence_number.txt for writing.\n");
    }
}



void ReadDFDR() {
    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Downloading");
    ssd1306_draw_string(&disp, 0, 20, 2, "FDR Data..");
    ssd1306_show(&disp);

    // Clear any incoming STDIO
    while (getchar_timeout_us(0) != PICO_ERROR_TIMEOUT);

    // Execute DFDR Download
    resultF = f_mount(&fatFs, "0:", 1);
    fp_dump = &fileO;

    // Increment the sequence number for the next file
    unsigned int sequenceNumber = readSequenceNumber();
    sequenceNumber++;

    // Use the tail number and sequence number to generate a unique filename
    char filename[256];
    sprintf(filename, "%s_%u.FDR", selectedTail, sequenceNumber);

    // Try to open the file. If it exists or can be created, proceed with the dump.
    if (f_open(fp_dump, filename, FA_WRITE | FA_CREATE_ALWAYS) == FR_OK) {
        // If the file is successfully opened/created, execute the dump.
        if (execute_dump()) {
            // Dump was successful
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "FDR");
            ssd1306_draw_string(&disp, 0, 20, 2, "Download");
            ssd1306_draw_string(&disp, 0, 40, 2, "Complete");
            ssd1306_show(&disp);
        } else {
            // Handle dump failure
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Dump Error");
            ssd1306_show(&disp);
        }
        f_close(fp_dump); // Always close the file after the operation
    } else {
        // If the file couldn't be opened/created, display an error message
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "File Error");
        ssd1306_show(&disp);
    }

    // Update the sequence number file
    writeSequenceNumber(sequenceNumber);

    resultF = f_unmount("0:"); // Unmount the filesystem

    sleep_ms(5000); // Wait a bit before clearing the display

    // Clear the display and show the original "Send", "Receive", and "List" page
    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Send (U)");
    ssd1306_draw_string(&disp, 0, 20, 2, "Receive (D)");
    ssd1306_draw_string(&disp, 0, 40, 2, "List (P)");
    ssd1306_show(&disp);
}


// Temporary File Functions
char pstring[200];
//char *fp_dump=NULL;

/*
unsigned char *XipBase = (unsigned char *)XIP_BASE;
char *FlashOpen() {
    // 
    // Initialize Flash Memory
    //
    int ptr;
    
//    while (!tud_cdc_n_available(0));
//    while (getchar_timeout_us(0) ==  PICO_ERROR_TIMEOUT);

    uint32_t IntSave = save_and_disable_interrupts();
    flash_range_erase (0x100000, FLASH_SECTOR_SIZE);

    unsigned char WriteBuffer[FLASH_PAGE_SIZE] = "1234567890.";
    flash_range_program (0x100000, WriteBuffer, FLASH_PAGE_SIZE);

    restore_interrupts (IntSave);

}
*/

/*
void f_putc (char c, char *file) {
    putchar_raw (c);
}

void f_write(char *fp_dump, char *buffer, int size, unsigned int *WriteCount) {
    int i;

    for (i=0; i<size; i++) {
        putchar_raw (buffer[i]);
    }
    *WriteCount = size;
    return (true);
}
*/

void PutString_Block (unsigned char *s) {
  int i=0;
  while (s[i] != 0)
    putchar_raw (s[i++]);
}

/* ------------------------------------------------------------------------ */
/*                      CRC Calculation Table                               */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This 256-word table is used for the table-lookup implementation of the   */
/* CRC-16calculation. Note that this table must be "public" since the CRC   */
/* functions are now "static inline'ed" via definitions in an "include"     */
/* file.                                                                    */
/*                                                                          */
/* ------------------------------------------------------------------------ */
const unsigned crc16_table [] = {
   0x0000, 0xc0c1, 0xc181, 0x0140, 0xc301, 0x03c0, 0x0280, 0xc241,
   0xc601, 0x06c0, 0x0780, 0xc741, 0x0500, 0xc5c1, 0xc481, 0x0440,
   0xcc01, 0x0cc0, 0x0d80, 0xcd41, 0x0f00, 0xcfc1, 0xce81, 0x0e40,
   0x0a00, 0xcac1, 0xcb81, 0x0b40, 0xc901, 0x09c0, 0x0880, 0xc841,
   0xd801, 0x18c0, 0x1980, 0xd941, 0x1b00, 0xdbc1, 0xda81, 0x1a40,
   0x1e00, 0xdec1, 0xdf81, 0x1f40, 0xdd01, 0x1dc0, 0x1c80, 0xdc41,
   0x1400, 0xd4c1, 0xd581, 0x1540, 0xd701, 0x17c0, 0x1680, 0xd641,
   0xd201, 0x12c0, 0x1380, 0xd341, 0x1100, 0xd1c1, 0xd081, 0x1040,
   0xf001, 0x30c0, 0x3180, 0xf141, 0x3300, 0xf3c1, 0xf281, 0x3240,
   0x3600, 0xf6c1, 0xf781, 0x3740, 0xf501, 0x35c0, 0x3480, 0xf441,
   0x3c00, 0xfcc1, 0xfd81, 0x3d40, 0xff01, 0x3fc0, 0x3e80, 0xfe41,
   0xfa01, 0x3ac0, 0x3b80, 0xfb41, 0x3900, 0xf9c1, 0xf881, 0x3840,
   0x2800, 0xe8c1, 0xe981, 0x2940, 0xeb01, 0x2bc0, 0x2a80, 0xea41,
   0xee01, 0x2ec0, 0x2f80, 0xef41, 0x2d00, 0xedc1, 0xec81, 0x2c40,
   0xe401, 0x24c0, 0x2580, 0xe541, 0x2700, 0xe7c1, 0xe681, 0x2640,
   0x2200, 0xe2c1, 0xe381, 0x2340, 0xe101, 0x21c0, 0x2080, 0xe041,
   0xa001, 0x60c0, 0x6180, 0xa141, 0x6300, 0xa3c1, 0xa281, 0x6240,
   0x6600, 0xa6c1, 0xa781, 0x6740, 0xa501, 0x65c0, 0x6480, 0xa441,
   0x6c00, 0xacc1, 0xad81, 0x6d40, 0xaf01, 0x6fc0, 0x6e80, 0xae41,
   0xaa01, 0x6ac0, 0x6b80, 0xab41, 0x6900, 0xa9c1, 0xa881, 0x6840,
   0x7800, 0xb8c1, 0xb981, 0x7940, 0xbb01, 0x7bc0, 0x7a80, 0xba41,
   0xbe01, 0x7ec0, 0x7f80, 0xbf41, 0x7d00, 0xbdc1, 0xbc81, 0x7c40,
   0xb401, 0x74c0, 0x7580, 0xb541, 0x7700, 0xb7c1, 0xb681, 0x7640,
   0x7200, 0xb2c1, 0xb381, 0x7340, 0xb101, 0x71c0, 0x7080, 0xb041,
   0x5000, 0x90c1, 0x9181, 0x5140, 0x9301, 0x53c0, 0x5280, 0x9241,
   0x9601, 0x56c0, 0x5780, 0x9741, 0x5500, 0x95c1, 0x9481, 0x5440,
   0x9c01, 0x5cc0, 0x5d80, 0x9d41, 0x5f00, 0x9fc1, 0x9e81, 0x5e40,
   0x5a00, 0x9ac1, 0x9b81, 0x5b40, 0x9901, 0x59c0, 0x5880, 0x9841,
   0x8801, 0x48c0, 0x4980, 0x8941, 0x4b00, 0x8bc1, 0x8a81, 0x4a40,
   0x4e00, 0x8ec1, 0x8f81, 0x4f40, 0x8d01, 0x4dc0, 0x4c80, 0x8c41,
   0x4400, 0x84c1, 0x8581, 0x4540, 0x8701, 0x47c0, 0x4680, 0x8641,
   0x8201, 0x42c0, 0x4380, 0x8341, 0x4100, 0x81c1, 0x8081, 0x4040
};

/* ------------------------------------------------------------------------ */
/* crc16_word  -  Update Specified CRC-16 Value with Specified Word         */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This function calculates the new CRC-16 value given the current value    */
/* and a new word to be processed. The updated 16-bit CRC value is returned */
/* as the function value.                                                   */
/*                                                                          */
/* Inputs  : Current CRC-16 value and new word to be processed              */
/*                                                                          */
/* Outputs : None                                                           */
/*                                                                          */
/* Returns : Updated CRC-16 value                                           */
/*                                                                          */
/* ------------------------------------------------------------------------ */
unsigned crc;
static unsigned crc16_word (unsigned crc_value, unsigned inword) {
   unsigned tbl_index;

   /* ---------------------------- */
   /* Handle hi byte of input word */
   /* ---------------------------- */
    crc_value &= 0xffff;
    tbl_index   = ((inword >> 8) & 0xff) ^ (crc_value & 0x00ff);
    crc_value >>= 8;
    crc_value  ^= crc16_table [tbl_index & 0xff];

   /* ---------------------------- */
   /* Handle lo byte of input word */
   /* ---------------------------- */
    crc_value &= 0xffff;
    tbl_index   = (inword & 0x00ff) ^ (crc_value & 0x00ff);
    crc_value >>= 8;
    crc_value  ^= crc16_table [tbl_index & 0xff];

   return (crc_value);
}

#define PKT_DISPLAY            0  /* Nonzero = Enable Packet Display        */
#define PKT_COUNT_REPORT       0  /* Nonzero = Packet-Count progress msgs   */
#define FIFO_SYNC_IMPLEMENTED  0  /* Nonzero = FIFO Sync Flag implemented   */
#define IGNORE_FD_RETRNSMT_WDS 1  /* Nonzero = Ignore TDM FD Retransmit Wds */
#define SHOW_TIMING            0  /* Nonzero = Show time next to msgs (RNS) */
#define SHOW_TRACE             0  /* Nonzero = Show SMP trace strings (RNS) */

/* ------------------------------------------------------------------------ */
/* Miscellaneous Constants and Definitions                                  */
/* ------------------------------------------------------------------------ */

#define SMP_TMOUT_MSECS     5000  /* FA2100 TDM timeout in 0.1 secs            */
#define RD_PKT_TMOUT_MSECS   500 /* Packet timeout in 0.1 secs                */
#define HSS_RETRAIN_MSECS    300  /* HSS quiet desired before packet retry  */
#define HSS_TMOUT_MSECS     5000  /* HSS timeout, giving up wait for quiet  */

#define FDR_DUMP_PKT_WDS     512  /* FDR Words per Dump Packet              */
#define CVR_DUMP_PKT_WDS     252  /* CVR Words per Dump Packet              */

#define NO_DUMP_MODE           0  /* Dump Mode Not Specified                */
#define FDR_FULL_DUMP          1  /* Full Dump of FDR Flash Memory          */
#define FDR_TIME_DUMP          2  /* Dump "FDR Last N Recorded Mins"        */
#define FDR_MARKER_DUMP        3  /* Dump "FDR Marker Range                 */
#define FDR_FROM_LAST_DUMP     4  /* Dump "FDR from Last Dump"              */
#define CVR_DUMP               5  /* CVR Dump                               */

/************************************************************************/
/***                                                                  ***/
/**                    DATA STRUCTURE DEFINITIONS                      **/
/***                                                                  ***/
/************************************************************************/

/************************************************************************/
/***                                                                  ***/
/**                    DATA SPACE                                      **/
/***                                                                  ***/
/************************************************************************/
word pkt_bfr [FDR_DUMP_PKT_WDS];

/************************************************************************/
/***                                                                  ***/
/**                    PROGRAM SPACE                                   **/
/***                                                                  ***/
/************************************************************************/
//-------------------------------------------------------------------------------------------------------------
// WriteArray
//--------------------------------------------------------------------------------------------------------------*/


/* ------------------------------------------------------------------------ */
/* reportf  - Formatted reporting messages (RNS)                            */
/* ------------------------------------------------------------------------ */
void (*_reporter)(char *) = PutString_Block;
void reportf(char *fmt, ...) {
    static char report_buffer[256];

    report_buffer[0]=0;
    
    if (_reporter != NULL) {
        #ifdef SHOW_TIMING
            sprintf (report_buffer, "%7.7u:", to_ms_since_boot(get_absolute_time()));
        #endif
        sprintf (report_buffer+strlen(report_buffer),fmt,
                                                   (long *)(&fmt+1)[0],
                                                   (long *)(&fmt+1)[1],
                                                   (long *)(&fmt+1)[2],
                                                   (long *)(&fmt+1)[3]);
        sprintf (report_buffer+strlen(report_buffer),"\xd\xa");
//      USBUART_PutString_Block (report_buffer); 
        (*_reporter) (report_buffer);
    }
}
/* ------------------------------------------------------------------------ */
/* reset_TDM_Rx_FIFO  -  Reset and Flush TDM Rx FIFO                        */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine flushes and resets the TDM Rx FIFO.                         */
/*                                                                          */
/* ------------------------------------------------------------------------ */

static void reset_TDM_Rx_FIFO (void){
   while (!EmptyQ (&RxTDMQ))
        PopQ(&RxTDMQ);

//   while (PopQ(&RxTDMQ) != 0xffffffff);
}

/* ------------------------------------------------------------------------ */
/* reset_HSS_Rx_FIFO  -  Reset and Flush HSS Rx FIFO                        */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine flushes and resets the HSS Rx FIFO.                         */
/*                                                                          */
/* ------------------------------------------------------------------------ */

static void reset_HSS_Rx_FIFO (void) {
   while (!EmptyQ (&RxHSSQ))
        PopQ(&RxHSSQ);

//   while (PopQ(&RxHSSQ) != 0xffffffff);
}

/* ------------------------------------------------------------------------ */
/* send_SMP_word  -  Xmit Word to SMP Via the CICC TDM Channel              */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine sends a single word to the FA2100 via the TDM Transmit      */
/* channel.                                                                 */
/*                                                                          */
/* ------------------------------------------------------------------------ */
static void send_SMP_word (word tx_wrd) {
//    unsigned tx;
//   io_rw_16 *TDMfifoDAT =  &tdm.pio->txf[(tdm.sm+1)];
//   io_rw_16 *TDMfifoADR =  &tdm.pio->txf[(tdm.sm+2)];
    unsigned RetryCnt=0;

//    sleep_ms(1);

    RetryCnt = 0;
    while ((pio_sm_is_tx_fifo_full (tdm.pio, tdm.sm+1)) && (RetryCnt++<2000))
  
    RetryCnt = 0;
    while ((!gpio_get(17)) && (RetryCnt++<2000));  // Hack to avoid skew in writing ADR vs DAT, wait for FRM pulse

    RetryCnt = 0;
    while ((gpio_get(17)) && (RetryCnt++<200));  // Hack to avoid skew in writing ADR vs DAT, wait for FRM pulse

    *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+2)]) = 0x4000;
    *((io_rw_16 *) &tdm.pio->txf[(tdm.sm+1)]) = tx_wrd;

//    *TDMfifoADR = 0x4000;
//    *TDMfifoDAT = tx_wrd;
//    printf ("+");
/*
    tx= 0x40000000;
    tx |= tx_wrd & 0xffff;
    PushQ (&TxTDMQ, tx);    

    if (KickTx_TDM) {
        TxTDM_isr_SetPending ();
        KickTx_TDM = 0;
    }
*/    
}

/* ------------------------------------------------------------------------ */
/* wait_HSS_word_or_tmout  - Wait for word on HSS or Timeout (RNS)          */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* Inputs  : Pointer to location to receive word; Timeout in msecs          */
/*           Timeout=0 means receive if already available, don't wait       */
/*                                                                          */
/*           Also takes start time as an input to avoid checking time       */
/*           with every single byte when receiving packets, which would     */
/*           slow things down tremendously.                                 */
/*                                                                          */
/* Outputs : Word returned in specified location                            */
/*                                                                          */
/* Returns : TRUE if word received (and stored at *pWrd), FALSE if timeout  */
/*                                                                          */
/* ------------------------------------------------------------------------ */
int wait_HSS_word_or_tmout (unsigned int stime, word *pWrd, word tmout_msecs) {
   unsigned rxWord;
    
   while ((to_ms_since_boot(get_absolute_time())-stime) <= tmout_msecs) {
        if (!EmptyQ(&RxHSSQ)) {
            rxWord = PopQ (&RxHSSQ);
            *pWrd = rxWord & 0xffff;
            return(TRUE);
        }
   }      
   return (FALSE);
}

/* ------------------------------------------------------------------------ */
/* wait_SMP_msg_or_tmout  -  Wait for SMP TDM Msg Word or Timeout           */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine waits for an SMP message word via the TDM interface. It     */
/* will continue to poll the SMP-to-GSE receive channel for a specified     */
/* number of milliseconds. If a message is received, it is written into the */
/* word location specified by the caller. If a timeout occurs, a "failure"  */
/* indicator is returned to the caller.                                     */
/*                                                                          */
/* Inputs  : Pointer to word location to receive msg; Timeout in msecs      */
/*           Timeout=0 means receive if already available, don't wait (RNS) */
/*                                                                          */
/* Outputs : Msg word returned in specified word location                   */
/*                                                                          */
/* Returns : TRUE if a msg word received, FALSE otherwise                   */
/*                                                                          */
/* ------------------------------------------------------------------------ */
static int wait_SMP_msg_or_tmout (word * pWrd, word tmout_msecs) {
    word tdat;
    unsigned int     stime;
    unsigned TDMword;

    stime = to_ms_since_boot(get_absolute_time()); /* Get start time */

    /* --------------------------------------------------------------------- */
    /* Wait for TDM word or a timeout at the SMP-to-GSE TDM FIFO.  This loop */
    /* will continue to execute until a  word is received or a               */
    /* timeout occurs. The caller of this routine must consider the effects  */
    /* of a stream of trace words on the timeout value. Note also that a     */
    /* single TDM word occupies three entries in the TDM FIFO. These are the */
    /* Hi and Lo bytes of TDAT, followed by the TADD value. The TADD value   */
    /* is discarded, but the Hi and Lo bytes of TDAT are combined into a     */
    /* 16-bit word, and returned in the caller-specified location.           */
    /* --------------------------------------------------------------------- */

    pstring[0] = 0;
    while (TRUE)  {/* Loop terminated internally */
//        while (((TDMword = PopQ(&RxTDMQ)) & 0x0f000000) != 0x08000000) {
        while (EmptyQ(&RxTDMQ)) {
//            ((TDMword = PopQ(&RxTDMQ)) & 0x0f000000) != 0x08000000) {
            if ((to_ms_since_boot(get_absolute_time()) - stime) >= tmout_msecs) {
                return (FALSE); /* Return timeout indication */
            }
        }

//        tdat = TDMword & 0xffff; 
        tdat = PopQ(&RxTDMQ); 

        #if IGNORE_FD_RETRNSMT_WDS /* Temp */
        /* -------------------------------- */
        /* Ignore any "FD Retransmit" words */
        /* -------------------------------- */
        if ((tdat & S2G_FD_RTRNSMT_DATA_MASK) == S2G_FD_RTRNSMT_DATA) {
            continue;
        }
        #endif

        /* -------------------------------- */
        /* Ignore FDP words - RDS HACK      */
        /* -------------------------------- */
        if ((tdat & 0xf000) == 0xf000) {
            continue;
        }


        if ((tdat & S2G_TDM_TRC_MASK) == S2G_TDM_TRC_WORD) {
            sprintf (pstring+strlen(pstring),"%c",tdat & 0x7f);
            if (strlen (pstring) >= 62) {
//                USBUART_PutString_Block (pstring);
                PutString_Block (pstring);
                pstring[0]=0;
            }
            continue;
        }

    if (strlen (pstring) > 0) 
//        USBUART_PutString_Block (pstring);
        PutString_Block (pstring);

    *pWrd = tdat; /* Non-trace word, into caller's loctn */
//      reportf ("TDM Rx 0x%04x",tdat);
    return (TRUE); /* Return "success" indication */
    }
}

/* ------------------------------------------------------------------------ */
/* rd_pkt_or_tmout  -  Wait for Packet from HSS or Timeout                  */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine waits for a full packet via the HSS or a timeout.           */
/*                                                                          */
/* Inputs  : Pkt size in wrds, Ptr to wrd CRC rcv loctn; Timeout in msecs.  */
/*                                                                          */
/* Outputs : CRC word returned in specified word location                   */
/*                                                                          */
/* Returns : TRUE if a Pkt received, FALSE otherwise                        */
/*                                                                          */
/* ------------------------------------------------------------------------ */
static int rd_pkt_or_tmout (word pkt_wds, word * pCRC, word tmout_msecs) {
    word crc, i, hss_wd;

    /* --------------------------------------------------- */
    /* Wait for a full packet via HSS channel or a timeout */
    /* --------------------------------------------------- */
    unsigned int stime = to_ms_since_boot(get_absolute_time());
    for (i = 0, crc = 0x0000; i < pkt_wds; i++) {                   
        /* --------------------------------------------------------------- */
        /* Wait for the HSS word or a timeout. If a timeout                */
        /* occurs, return to caller with timeout indication.               */
        /* --------------------------------------------------------------- */
        if (! wait_HSS_word_or_tmout(stime, &hss_wd, tmout_msecs)) {
            reportf ("Timeout on HSS Pkt, word %u",i);
            return(FALSE);
        }

        crc = crc16_word (crc, hss_wd); /* Updt CRC with new word */
        pkt_bfr[i] = hss_wd; /* Store word in packet buffer */
    }
   
    /* ----------------------------------------------- */
    /* Store CRC in caller's loctn - Rtrn success code */
    /* ----------------------------------------------- */
    *pCRC = crc & 0xffff;
                    
    return (TRUE);
}

/* ------------------------------------------------------------------------ */
/* get_hdr_or_tmout  -  Wait for Dump-File Hdr Text from SMP or Timeout     */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine waits for the Dump-File Header Text from the SMP via the    */
/* TDM SMP-to-GSE channel, or a timeout. It will poll the SMP-to-GSE Rx     */
/* channel for "ASCII Text" messages until one is received with the "End"   */
/* mark, or the specified number of timeout milliseconds has elapsed while  */
/* waiting for a message. As the messages are received, an ASCII character  */
/* is extracted from each one and written to the Dump File. If a timeout    */
/* occurs, or an invalid word is received, a "failure" code is returned to  */
/* the caller.                                                              */
/*                                                                          */
/* Inputs  : Timeout in msecs                                               */
/*                                                                          */
/* Outputs : ASCII Text is written to Dump File                             */
/*                                                                          */
/* Returns : TRUE if no timeout and "End" msg detected, FALSE otherwise     */
/*                                                                          */
/* ------------------------------------------------------------------------ */
static int get_hdr_or_tmout (word tmout) {
   word smp_wd, cnt = 0;
   word wc = 0;

    /* ------------------------------------------------------------------- */
    /* Keep processing SMP-to-GSE "ASCII Text" messages until timeout, bad */
    /* message, or a valid "end word" message is detected.                 */
    /* ------------------------------------------------------------------- */
    do {
        /* ---------------------------------------------------------- */
        /* Wait for, and validate next "ASCII Text" msg word from SMP */
        /* ---------------------------------------------------------- */
        if (! wait_SMP_msg_or_tmout (&smp_wd, tmout)) { /* If not rcvd */
            reportf ("Timeout on ASCII Header Word");
            return (FALSE);
        }

	    wc++;
        if ((smp_wd & S2G_ASCII_TEXT_MASK) != S2G_ASCII_TEXT) {
            reportf ("Expctd ASCII Hdr Word - Rcvd 0x%04x", smp_wd);
            return (FALSE);
        }

        cnt++; /* Bump the count of words received */

        /* ------------------------------------------------------- */
        /* Extract ASCII Char from msg word and write to Dump File */
        /* ------------------------------------------------------- */
        if (fp_dump != NULL) {
            f_putc (smp_wd & 0x007f, fp_dump); /* Hdr char to output file */
        }

    } while ((smp_wd & S2G_ASCII_TEXT_END_FLAG) == 0); /* Not "end" yet */
                                      
    /* --------------------------------------------------------------------- */
    /* If the Header Text contained an odd number of characters, output an   */
    /* additional "space" character so that an even number of characters are */
    /* written to the file. This is done to maintain "word alignment" in the */
    /* output file for convenience in the "PC" (Intel) world.                */
    /* --------------------------------------------------------------------- */
    if (cnt & 0x0001) { /* If odd number of chars in Hdr Text */
        if (fp_dump != NULL) {
            f_putc (' ', fp_dump); /* Space char to output file */
        }
    }

    /* -------------------------- */
    /* Return with "Success" code */
    /* -------------------------- */
    return (TRUE);
}


/* ------------------------------------------------------------------------ */
/* execute_dump  -  Execute CVR or FDR Dump Operation Until Done or Timeout */
/* ------------------------------------------------------------------------ */
/*                                                                          */
/* This routine implements the "FDR or CVR Dump" operation. Upon entry to   */
/* this routine, the "Dump" has already been initiated by the User.         */
/*                                                                          */
/* This routine sends the "Set Dump Packet Size" command (if required) and  */
/* the "FDR or CVR Dump" command to the SMP via the TDM bus, then waits for */
/* the appropriate response sequence. Once the required responses have been */
/* received, the routine sends the first "Next Packet Go" command to the    */
/* SMP, then starts polling the High-Speed Serial port in order to monitor  */
/* the Dump Data coming from Flash memory. The incoming data is stored and  */
/* the block CRC is checked. A "Block CRC" message is received from the SMP */
/* after the Block has been transferred. If this message agrees with the    */
/* computed CRC, then the block can be stored and a new "Next Packet Go"    */
/* command can be sent to the SMP for the next block. Whenever a block CRC  */
/* validation fails, a "Previous Packet Go" message is sent to the SMP.     */
/* This causes the SMP to repeat the previous block.                        */
/*                                                                          */
/* When the SMP is sending the last packet of a "Data Dump", the packet is  */
/* marked with a "Done" flag. If the CRC validation is successful on the    */
/* last packet, the GSE sends a "Terminate Dump" command to the SMP.        */
/*                                                                          */
/* This routine will terminate and return to the caller only after the Dump */
/* operation has been terminated, or if a timeout occurs while waiting for  */
/* a TDM or High-Speed Serial transmission from the SMP. This can occur if  */
/* the FA2100 has a problem of some sort.                                   */
/*                                                                          */
/* NOTE: There is an underlying assumption that the "packet size" can be    */
/* evenly divided into a Flash erase block.                                 */
/*                                                                          */
/* Inputs  : Mode, Number of Mins (0 if Not Used), Marker (0 if Not Used),  */
/*         : Ptr to word location for Retries count                         */
/*                                                                          */
/* Outputs : Messages to SMP, Data to Store, etc., Retry counter            */
/*                                                                          */
/* Returns : TRUE if Success, FALSE otherwise                               */
/*                                                                          */
/* ------------------------------------------------------------------------ */
boolt execute_dump (void) {
    word  msg, blk_crc, smp_crc,  pkt_cnt, pkt_tries;
    word qual, blk_pairs, pkt_wds;
    int done, retry;
    int retries = 0;
    unsigned int WriteCount;
    word mode = FDR_FULL_DUMP;
    word mins = 0;
    word mkr=0; 
    char PacifierString[20];

    
    #if PKT_DISPLAY /* If Packet Display enabled */
    char pktdisp[5*8+1];
    #endif
        
    // clear fifos             
    reset_TDM_Rx_FIFO ();
    reset_HSS_Rx_FIFO ();

    /* --------------------------------------------------------------------- */
    /* If not a "CVR Dump" Send Packet Size Cmd to the SMP and get Response. */
    /* For a CVR Dump, the Packet Size is currently fixed, based on the      */
    /* constant, "CVR_DUMP_FRMS_PER_PKT".                                    */
    /* --------------------------------------------------------------------- */
   
    if (mode != CVR_DUMP) { /* If any form of FDR dump */
        /* --------------------------------------------------------------- */
        /* Set Packet Size in words for calls to the "Read Packet" routine */
        /* --------------------------------------------------------------- */
        pkt_wds = FDR_DUMP_PKT_WDS; /* Set packet size */

        /* ------------------------ */
        /* Send Pkt Size Msg to SMP */
        /* ------------------------ */
        send_SMP_word (G2S_DUMP_PKT16X_WDS | ((FDR_DUMP_PKT_WDS >> 4) & 0x00ff));

        /* -------------------------------------------- */
        /* Wait for the "Packet Size Echo" from the SMP */
        /* -------------------------------------------- */
        if (! wait_SMP_msg_or_tmout (&msg, SMP_TMOUT_MSECS)) { /* If not rcvd */
            reportf ("Timeout on Pkt Sz Echo from SMP");
            return (FALSE); /* Exit with "Fail" status */
        }

        if (msg != (G2S_DUMP_PKT16X_WDS | ((FDR_DUMP_PKT_WDS >> 4) & 0x00ff))) {
            reportf ("Expctd Pkt Sz Echo from SMP, Rcvd 0x%04x", msg);
            return (FALSE); /* Exit with "Fail" status */
        }
        
        reportf("Got pkt size: 0x%04X", msg);
    } else { /* This is a CVR Dump */
        /* --------------------------------------------------------------- */
        /* Set Packet Size in words for calls to the "Read Packet" routine */
        /* --------------------------------------------------------------- */
        pkt_wds = CVR_DUMP_PKT_WDS; /* Set packet size */
    }

    /* ------------------------------- */
    /* Send CVR or FDR Dump cmd to SMP */
    /* ------------------------------- */
    if (mode == CVR_DUMP) { /* If CVR Dump */
        send_SMP_word (G2S_CVR_DUMP | (mins & G2S_CVR_DUMP_QUAL_MASK));
    } else if ((mode == FDR_FULL_DUMP) || (mins == 0)) { /* This indicates Full dump */
        send_SMP_word (G2S_FDR_DUMP | G2S_FDR_FULL_DUMP);
    } else if (mode == FDR_TIME_DUMP) { /* Doing "time" dump */
        send_SMP_word (G2S_FDR_DUMP | G2S_FDR_TIME_DUMP);
        /* ---------------------------------------------------------------- */
        /* Dump time is specified in ten-minute units, so the minutes value */
        /* passed to this routine must be divided by ten.                   */
        /* ---------------------------------------------------------------- */
        send_SMP_word (G2S_FDR_DUMP_TIME | ((mins / 10) & 0x00ff));
    } else { /* Must be "Marker" or "Last Dump" mode */
        if (mode == FDR_FROM_LAST_DUMP) {
            qual = 0x000f;
        } else { /* "Dump from Marker" mode */
            qual = (mkr << 4) & 0x00f0;
        }
        send_SMP_word (G2S_FDR_DUMP | qual);
    }

    /* ------------------------------------------------------------------ */
    /* Wait for the "Number of Block Pairs to be Dumped" Msg from the SMP */
    /* ------------------------------------------------------------------ */
    if (! wait_SMP_msg_or_tmout (&msg, SMP_TMOUT_MSECS)) { /* If not rcvd */
        reportf ("Timeout on Blk-Pairs Msg from SMP");
        return (FALSE); /* Exit with "Fail" status */
    }

    if ((msg & S2G_DUMP_BLK_PAIRS_MASK) != S2G_DUMP_BLK_PAIRS) {
        reportf ("Expctd Blk Pairs from SMP, Rcvd 0x%04x", msg);
        return (FALSE); /* Exit with "Fail" status */
    }

    /* --------------------------------------------------------------------- */
    /* Extract "Block Pairs to be Dumped" from Message and Report it. If the */
    /* "Block Pairs" value is "zero", then an invalid dump request has been  */
    /* made, and the SMP will not be proceeding with the Dump operation.     */
    /* --------------------------------------------------------------------- */
    blk_pairs = msg & S2G_DUMP_BLK_PAIRS_QMASK; /* Get Blk Pairs from Msg */
    if (blk_pairs == 0) { /* If "zero" pairs */
        reportf ("SMP Zero Blks Response Indicates Invalid Dump Request");
        return (FALSE); /* Exit with "Fail" status */
    }
    reportf ("SMP Will Dump %u Block Pairs", blk_pairs);

    /* ------------------------------------------------------------------- */
    /* Get Dump-File Hdr Text messages from the SMP and write to Dump File */
    /* ------------------------------------------------------------------- */
    if (! get_hdr_or_tmout (SMP_TMOUT_MSECS)) { /* If not rcvd */
        reportf ("Error on File Header Text from SMP");
        return (FALSE); /* Exit with "Fail" status */
    }

    /* ------------------------------------------- */
    /* Wait for the "Ready" indicator from the SMP */
    /* ------------------------------------------- */
    if (! wait_SMP_msg_or_tmout (&msg, SMP_TMOUT_MSECS)) { /* If not rcvd */
        reportf ("Timeout on RDY response from SMP");
        return (FALSE); /* Exit with "Fail" status */
    }

    if ((msg & S2G_RDY_TO_DUMP_MASK) != S2G_RDY_TO_DUMP) {
        reportf ("Expctd Dump Rdy from SMP, Rcvd 0x%04x", msg);
        return (FALSE); /* Exit with "Fail" status */
    }

    /* ------------------ */
    /* Top of "Dump" loop */
    /* ------------------ */
    done    = FALSE;
    retry   = FALSE;
    pkt_cnt = 0;
    
    /* -------------------------------------------------------- */
    /* Flush HSS FIFO before sending the "Go" command to FA2100 */
    /* -------------------------------------------------------- */
    reset_HSS_Rx_FIFO (); /* Reset and flush HSS Rx FIFO */

    while (TRUE) { /* Loop terminated internally */
//        if (!EmptyQ(&RxHSSQ)) {
//            reset_HSS_Rx_FIFO ();
//            reportf ("Extra data in HSS queue");
//        }

        /* -----------------------------------------------r------- */
        /* Check for a "User Abort" command, and Exit if detected */
        /* ------------------------------------------------------ */
//        if (USBUART_DataIsReady()) {
    
        if (getchar_timeout_us(0) !=  PICO_ERROR_TIMEOUT) {
//        if (tud_cdc_n_available(0)) {
            reportf ("User Abort Detected, %u-Word Pkt Count = 0x%04x ",
                  pkt_wds, pkt_cnt);
            break;          // Exit with "Fail" status 
        }

        /* ---------------------------------------------------------------- */
        /* If "retry" flag is set, check for Max tries and Exit if reached. */
        /* If no "retry" needed, check "done" flag and exit if done. If not */
        /* done, issue the "Next Packet Go" command to the FA2100.          */
        /* ---------------------------------------------------------------- */
        if (retry) { /* Current packet not sent successfully */
            ++retries; /* Bump the accumulated retries counter */

            if (++pkt_tries == 5) { /* If reached max tries for a packet */
                reportf ("Max Pkt Tries (%u) Attempted,"
                        " %u-Word Pkt Count = 0x%04x",
                            pkt_tries, pkt_wds, pkt_cnt);
                break;          /* Exit with "Fail" status */
            }

            /* -------------------------------------------------------- */
            /* OK to try again - Begin by sending the "Prev Pkt Go" cmd */
            /* -------------------------------------------------------- */
            retry = FALSE; /* Reset the "retry" flag */
            send_SMP_word (G2S_PREV_PKT_GO);
        } else if (done) { /* No retry, Done rcvd, Issue "Terminate Dump" cmd */
            send_SMP_word (G2S_TERMINATE_DUMP);
            reportf ("Successful Termination, %u Retries", retries);
            return (TRUE); /* Normal "success" exit */
        } else { /* No retry and not done - Issue "Next Block Go" cmd */
            pkt_tries = 0; /* Initialize "packet-tries" counter */
            send_SMP_word (G2S_NEXT_PKT_GO);
        }
  
        /* ------------------------------------------------------------- */
        /* Wait for the two msgs from SMP containing CRC Hi and Lo bytes */
        /* ------------------------------------------------------------- */
        if (! wait_SMP_msg_or_tmout (&msg, SMP_TMOUT_MSECS)) { /* If not rcvd */
            // reportf ("Timeout on CRC Hi Msg from SMP");
            // retry = TRUE; /* Set flag for retry */
            // continue; /* To top of "while" loop */
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Error");
            ssd1306_draw_string(&disp, 0, 20, 2, "Timeout");
            ssd1306_show(&disp);
            return (FALSE); // Exit with "Fail" status
        }

        if ((msg & S2G_BLOCK_CRC_MASK) != S2G_BLOCK_CRC) {
            reportf ("Expctd CRC Msg from SMP, Rcvd 0x%04x", msg);
            retry = TRUE; /* Set flag for retry */
            continue; /* To top of "while" loop */
        }

        smp_crc = (msg & 0xff) << 8; /* Assume Hi byte */
        
        if (! wait_SMP_msg_or_tmout (&msg, SMP_TMOUT_MSECS)) { /* If not rcvd */
            reportf ("Timeout on CRC Lo Msg from SMP");
            retry = TRUE; /* Set flag for retry */
            continue; /* To top of "while" loop */
        }

        if ((msg & S2G_BLOCK_CRC_MASK) != S2G_BLOCK_CRC) {
            reportf ("Expctd CRC Msg from SMP, Rcvd 0x%04x", msg);
            retry = TRUE; /* Set flag for retry */
            continue; /* To top of "while" loop */
        }

        smp_crc += msg & 0x00ff; /* Assume Lo byte */

        /* ----------------------------------------- */
        /* Read dump data via High-Speed serial port */
        /* ----------------------------------------- */
        if (! rd_pkt_or_tmout (pkt_wds, &blk_crc, RD_PKT_TMOUT_MSECS)) {
            reportf ("Error or Timeout on Pkt Data from SMP");
            retry = TRUE; /* Set flag for retry */
            continue; /* To top of "while" loop */
        }

        /* ----------------------------------------------------------- */
        /* Set "done" flag if flag bit set in the CRC message from SMP */
        /* ----------------------------------------------------------- */
        done = done  | ((msg & S2G_CRC_DONE_FLAG) != 0);

        #if PKT_DISPLAY /* If Packet Display enabled */
        /* -------------------------------------------------------- */
        /* If Packet Display is enabled, write packet to the screen */
        /* -------------------------------------------------------- */
        pktdisp[0] = '\0';
        for (i = 0; i < pkt_wds; i++) {
            sprintf (pktdisp+strlen(pktdisp), " 0x%04x", pkt_bfr[i]);

            if ((i % 8) == 7 || i == pkt_wds-1) {
                reportf (pktdisp);
                pktdisp[0] = '\0';
            }
        }
        #endif

        /* ----------------------------------------------------------------- */
        /* Set "retry" flag if CRC from SMP does not match local calculation */
        /* ----------------------------------------------------------------- */
        if ((smp_crc != blk_crc) && (done == 0)) {
            reportf ("Blk %04x CRC Error: SMP CRC = 0x%04x, PI CRC = 0x%04x",
                        pkt_cnt,smp_crc, blk_crc);
            retry = TRUE; /* Set flag for retry */

            if (!EmptyQ(&RxHSSQ)) {
                reset_HSS_Rx_FIFO ();
                reportf ("Extra data in HSS queue");
        }
            continue; /* To top of "while" loop */
        }

        /* ------------------------------------------------------------- */
        /* Fall-thru to here indicates packet was received without error */
        /* ------------------------------------------------------------- */
        pkt_cnt++;    // count good packet (RNS)

        #if PKT_COUNT_REPORT
        /* ------------------------------------------------------- */
        /* Report progress if packet count report interval reached */
        /* ------------------------------------------------------- */
        if ((pkt_cnt % 32) == 0) {
            reportf ("%u-Word Pkt Count = 0x%04x ", pkt_wds, pkt_cnt);
        }
        #endif

        /* -------------------------------------------------------------- */
        /* If file is open, write the packet to the output file           */
        /* -------------------------------------------------------------- */
        if (fp_dump != NULL) {
            f_write(fp_dump,pkt_bfr,2*pkt_wds,&WriteCount);
        }

        /* -------------------------------------------------------- */
        /* User Pacifier                                            */
        /* -------------------------------------------------------- */
        if ((pkt_cnt % 128) == 0) {
            sprintf (PacifierString,"%i",pkt_cnt/128);
            ssd1306_clear(&disp);
            ssd1306_draw_string(&disp, 0, 0, 2, "Downloading");
            ssd1306_draw_string(&disp, 0, 20, 2, "FDR Data..");
            ssd1306_draw_string(&disp,0,40,2,PacifierString);
            ssd1306_draw_string(&disp, 40,40, 2," Blocks");
            ssd1306_show(&disp); 
        }


    }
    
    reportf ("Dump Incomplete, %u Retries", retries);
    return (FALSE);
}
/* [] END OF FILE */

/* ------------------------------------------------------- */
/* List of files in the SD card */
/* ------------------------------------------------------- */
void list_files(void) {
    DIR dir;
    FILINFO fno;
    FRESULT fr;
    unsigned int fileCount = 0; // Initialize file counter
    char displayBuffer[32]; // Buffer to hold the display text

    // Mount SD card
    fr = f_mount(&fatFs, "", 0);
    if (fr != FR_OK) {
        printf("Failed to mount filesystem\n");
        return;
    }

    // Open the directory
    fr = f_opendir(&dir, "/"); // Open the root directory
    if (fr == FR_OK) {
        for (;;) {
            fr = f_readdir(&dir, &fno); // Read a directory item
            if (fr != FR_OK || fno.fname[0] == 0) break; // Break on error or end of dir
            
            // Check if it is a file and does not start with ._
            if (!(fno.fattrib & AM_DIR) && strncmp(fno.fname, "._", 2) != 0) { 
                fileCount++; // Increment file counter
                printf("FILE: %s\n", fno.fname); // Print the file name to the terminal
            }
        }
        f_closedir(&dir);
    } else {
        printf("Failed to open directory\n");
    }

    // Prepare the display text with the file count
    snprintf(displayBuffer, sizeof(displayBuffer), "%u file%s", fileCount, fileCount == 1 ? "" : "s");

    // Display the file count on the SSD1306
    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, displayBuffer);
    ssd1306_show(&disp);

    // Unmount SD card
    f_mount(NULL, "", 0);

    // Optional: Return to a default screen or message after displaying the file count
    sleep_ms(5000); // Wait for a bit before clearing the display
    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Send (U)");
    ssd1306_draw_string(&disp, 0, 20, 2, "Receive (P)");
    ssd1306_draw_string(&disp, 0, 40, 2, "List (D)");
    ssd1306_show(&disp);
}




/* ------------------------------------------------------- */
/* Create Custom Tail */
/* ------------------------------------------------------- */

void DisplayWordUpdate() {
    ssd1306_clear(&disp);
    ssd1306_draw_string(&disp, 0, 0, 2, "Tails:");
    ssd1306_draw_string(&disp, 0, 20, 2, selectedWord);
    ssd1306_show(&disp);
}

void updateSelectedWord(int direction) {
    // For the first character, cycle through A-Z
    if (selectedLetterIndex == 0) {
        if (direction > 0) {
            if (selectedWord[selectedLetterIndex] == 'Z') selectedWord[selectedLetterIndex] = 'A';
            else selectedWord[selectedLetterIndex]++;
        } else {
            if (selectedWord[selectedLetterIndex] == 'A') selectedWord[selectedLetterIndex] = 'Z';
            else selectedWord[selectedLetterIndex]--;
        }
    } else {
        // For other characters, cycle through 0-9
        if (direction > 0) {
            if (selectedWord[selectedLetterIndex] == '9') selectedWord[selectedLetterIndex] = '0';
            else selectedWord[selectedLetterIndex]++;
        } else {
            if (selectedWord[selectedLetterIndex] == '0') selectedWord[selectedLetterIndex] = '9';
            else selectedWord[selectedLetterIndex]--;
        }
    }

    DisplayWordUpdate();
}

void handleInputs() {
    bool currentStateUp, currentStateDown, currentStateNext, currentStatePrev;
    bool currentStateAccept;
    selectedLetterIndex = 0; // Start from the first character

    while (true) {
        currentStateDown = !gpio_get(5); // Assuming GPIO 5 is "down"
        currentStateUp = !gpio_get(3); // Assuming GPIO 3 is "up"
        currentStateNext = !gpio_get(4); // Assuming GPIO 4 is "next"
        // currentStateAccept = !gpio_get(2); // Assuming GPIO 2 is "accept", replace with correct GPIO

        if (currentStateUp) {
            updateSelectedWord(1);
            sleep_ms(200); // Adjust timing as needed
        } else if (currentStateDown) {
            updateSelectedWord(-1);
            sleep_ms(200); // Adjust timing as needed
        }

        if (currentStateNext) {
            if (selectedLetterIndex < 6) { // Last character is at index 6
                selectedLetterIndex++;
                DisplayWordUpdate();
            } else {
                // If on the last character and next is pressed, assume completion
                // Here you could directly call ReadDFDR, or set a flag to do it after breaking the loop
                ReadDFDR(); // Start FDR download with the current selectedWord
                break; // Exit input loop after starting download
            }
            sleep_ms(200); // Debounce delay
        }

    }
}



/* ------------------------------------------------------- */
/* Atmoshpere Tails Display */
/* ------------------------------------------------------- */

extern ssd1306_t disp; // Assuming the display is initialized elsewhere
extern FATFS fatFs;    // Assuming the FATFS object is available globally

void displayAtmo(int entryIndex) {
    FIL fil; // File object
    FRESULT fr; // Result code
    char line[256]; // Buffer to hold lines read from the file
    int currentEntry = 0; // Tracks the current entry index in the file
    bool isAtmosphereSection = false; // Flag to indicate we're in the "Atmosphere" section
    bool validDataFound = false; // Flag to indicate if valid data has been found for the current entry
    bool endOfValidDataReached = false; // Flag to indicate the end of valid data has been reached
    
    // Attempt to mount the filesystem
    fr = f_mount(&fatFs, "", 0);
    if (fr != FR_OK) {
        printf("Failed to mount filesystem, error: %d\n", fr);
        return;
    }

    // Attempt to open the file
    fr = f_open(&fil, "AtmosphereTails.txt", FA_READ);
    if (fr != FR_OK) {
        printf("Failed to open file, error: %d\n", fr);
        f_mount(NULL, "", 0); // Attempt to unmount the filesystem if needed
        return;
    }

    // Loop through the file to find the requested entry index
    while (!endOfValidDataReached && f_gets(line, sizeof(line), &fil)) {
        if (skipNextLine) {
            skipNextLine = false; // Reset the flag after skipping
            continue; // Skip the line
        }
        if (strstr(line, "Atmosphere")) {
            isAtmosphereSection = true;
            skipNextLine = true;
            continue; // Skip the "Atmosphere" header line
        }

        if (isAtmosphereSection && line[0] != '\n' && line[0] != '\r') { // Check for non-empty line
            currentEntry++;
            if (currentEntry == entryIndex) {
                // Found the desired entry
                validDataFound = true;
                break;
            }
        } else if (isAtmosphereSection && (line[0] == '\n' || line[0] == '\r')) {
            // Empty line within the section, could indicate the end of valid data
            endOfValidDataReached = true;
        }
    }

    // Additional check to ensure we handle the case where we're exactly one past the last entry
    if (!validDataFound && endOfValidDataReached) {
        // Directly show "Enter Serial" prompt without additional clicks
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Enter");
        ssd1306_draw_string(&disp, 0, 20, 2, "Serial");
        ssd1306_show(&disp);
        isOnSerial = true;
    } else if (validDataFound) {
        if (isAtmosphereSection && currentEntry == entryIndex) {
        char* token = strtok(line, "\t"); // Assuming tab delimiter
        char ac[20]; // Aircraft registration code
        char sn[20]; // Serial number
        if (token) {
            strncpy(ac, token, sizeof(ac)); // Copy A/C
            token = strtok(NULL, "\t");
            if (token) {
                strncpy(sn, token, sizeof(sn)); // Copy S/N
            }
        }

        // Display the content on the SSD1306
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Atmosphere");
        ssd1306_draw_string(&disp, 0, 16, 2, ac);
        ssd1306_draw_string(&disp, 0, 32, 2, sn);
        ssd1306_show(&disp);
        isOnNewAtmosphere = true;
    strncpy(selectedTail, ac, sizeof(selectedTail) - 1);
    strncpy(selectedSerial, sn, sizeof(selectedSerial) - 1);

    }
    } 

    // Close the file and unmount the filesystem as before
    f_close(&fil);
    f_mount(NULL, "", 0);
}

void handleScrollDownAtmo() {
    currentIndex++; // Increment the current index to display the next entry
    displayAtmo(currentIndex);

    sleep_ms(500); // Delay for 1000 milliseconds (1 second) before allowing another action
}

// Call this function when the user presses the "scroll up" button
void handleScrollUpAtmo() {
    if (currentIndex > 0) {
        currentIndex--; // Decrement the current index to display the previous entry
        displayAtmo(currentIndex);

        sleep_ms(500); // Delay for 1000 milliseconds (1 second) before allowing another action
    }
}
/* ------------------------------------------------------- */
/* Create Custom Tail */
/* ------------------------------------------------------- */


void displayClassic(int entryIndex) {
    FIL fil; // File object
    FRESULT fr; // Result code
    char line[256]; // Buffer to hold lines read from the file
    int currentEntryClassic = 0; // Tracks the current entry index in the file
    bool isClassicSection = false; // Flag to indicate we're in the "Atmosphere" section
    
    // Attempt to mount the filesystem
    fr = f_mount(&fatFs, "", 0);
    if (fr != FR_OK) {
        printf("Failed to mount filesystem, error: %d\n", fr);
        return;
    }

    // Attempt to open the file
    fr = f_open(&fil, "ClassicTails.txt", FA_READ);
    if (fr != FR_OK) {
        printf("Failed to open file, error: %d\n", fr);
        // Attempt to unmount the filesystem if needed
        f_mount(NULL, "", 0);
        return;
    }

    // Loop through the file to find the requested entry index
    while (f_gets(line, sizeof(line), &fil)) {
            if (skipNextLine) {
            skipNextLine = false; // Reset the flag after skipping
            continue; // Skip the line
        }
        // Identify the "Atmosphere" section
        if (strstr(line, "Classic")) {
            isClassicSection = true;
             skipNextLine = true;
            continue; // Skip the "Atmosphere" header line
        }
        if (isClassicSection) {
            // Increment currentEntry for each line in the "Atmosphere" section
            if (++currentEntryClassic == entryIndex) {
                // Found the desired entry, break to display it
                break;
            }
        }
    }

    // Display the found entry if in the "Atmosphere" section and at the correct entry
    if (isClassicSection && currentEntryClassic == entryIndex) {
        char* token = strtok(line, "\t"); // Assuming tab delimiter
        char ac[20]; // Aircraft registration code
        char sn[20]; // Serial number
        if (token) {
            strncpy(ac, token, sizeof(ac)); // Copy A/C
            token = strtok(NULL, "\t");
            if (token) {
                strncpy(sn, token, sizeof(sn)); // Copy S/N
            }
        }

        // Display the content on the SSD1306
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Classic");
        ssd1306_draw_string(&disp, 0, 16, 2, ac);
        ssd1306_draw_string(&disp, 0, 32, 2, sn);
        ssd1306_show(&disp);
        isNewClassic = true;
        strncpy(selectedTail, ac, sizeof(selectedTail) - 1);
        strncpy(selectedSerial, sn, sizeof(selectedSerial) - 1);
    } else {
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Enter");
        ssd1306_draw_string(&disp, 0, 20, 2, "Serial");
        ssd1306_show(&disp);
        isOnSerial = true;
 
    }

    // Close the file
    f_close(&fil);
    // Unmount the filesystem
    f_mount(NULL, "", 0);
}


void handleScrollDownClassic() {
    currentIndexClassic++; // Increment the current index to display the next entry
    displayClassic(currentIndexClassic);

    sleep_ms(500); // Delay for 1000 milliseconds (1 second) before allowing another action
}

void handleScrollUpClassic() {
    if (currentIndexClassic > 0) {
        currentIndexClassic--; // Decrement the current index to display the previous entry
        displayClassic(currentIndexClassic);

        sleep_ms(500); // Delay for 1000 milliseconds (1 second) before allowing another action
    }
}



void displayNextGen(int entryIndex) {
    FIL fil; // File object
    FRESULT fr; // Result code
    char line[256]; // Buffer to hold lines read from the file
    int currentEntryNG = 0; // Tracks the current entry index in the file
    bool isNextGenSection = false; // Flag to indicate we're in the "Atmosphere" section
    
    // Attempt to mount the filesystem
    fr = f_mount(&fatFs, "", 0);
    if (fr != FR_OK) {
        printf("Failed to mount filesystem, error: %d\n", fr);
        return;
    }

    // Attempt to open the file
    fr = f_open(&fil, "NextGenTails.txt", FA_READ);
    if (fr != FR_OK) {
        printf("Failed to open file, error: %d\n", fr);
        // Attempt to unmount the filesystem if needed
        f_mount(NULL, "", 0);
        return;
    }

    // Loop through the file to find the requested entry index
    while (f_gets(line, sizeof(line), &fil)) {
        if (skipNextLine) {
            skipNextLine = false; // Reset the flag after skipping
            continue; // Skip the line
        }
        // Identify the "Atmosphere" section
        if (strstr(line, "Next Gen")) {
            isNextGenSection = true;
            skipNextLine = true;
            continue; // Skip the "Atmosphere" header line
        }
        if (isNextGenSection) {
            // Increment currentEntry for each line in the "Atmosphere" section
            if (++currentEntryNG == entryIndex) {
                // Found the desired entry, break to display it
                break;
            }
        }
    }
    if (isNextGenSection && currentEntryNG == entryIndex) {
        char* token = strtok(line, "\t"); // Assuming tab delimiter
        char ac[20]; // Aircraft registration code
        char sn[20]; // Serial number
        if (token) {
            strncpy(ac, token, sizeof(ac)); // Copy A/C
            token = strtok(NULL, "\t");
            if (token) {
                strncpy(sn, token, sizeof(sn)); // Copy S/N
            }
        }

        // Display the content on the SSD1306
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Next Gen");
        ssd1306_draw_string(&disp, 0, 16, 2, ac);
        ssd1306_draw_string(&disp, 0, 32, 2, sn);
        ssd1306_show(&disp);
        isNewNextGen = true;
        strncpy(selectedTail, ac, sizeof(selectedTail) - 1);
        strncpy(selectedSerial, sn, sizeof(selectedSerial) - 1);
    } else {
        ssd1306_clear(&disp);
        ssd1306_draw_string(&disp, 0, 0, 2, "Enter");
        ssd1306_draw_string(&disp, 0, 20, 2, "Serial");
        ssd1306_show(&disp);
        isOnSerial = true;
    }

    // Close the file
    f_close(&fil);
    // Unmount the filesystem
    f_mount(NULL, "", 0);
}

void handleScrollDownNG() {
    currentIndexNG++; // Increment the current index to display the next entry
    displayNextGen(currentIndexNG);

    sleep_ms(500); // Delay for 1000 milliseconds (1 second) before allowing another action
}

void handleScrollUpNG() {
    if (currentIndexNG > 0) {
        currentIndexNG--; // Decrement the current index to display the previous entry
        displayNextGen(currentIndexNG);

        sleep_ms(500); // Delay for 1000 milliseconds (1 second) before allowing another action
    }
}